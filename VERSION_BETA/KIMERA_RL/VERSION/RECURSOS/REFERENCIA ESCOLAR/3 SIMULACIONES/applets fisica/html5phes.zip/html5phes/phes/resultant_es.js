// Ersatzkraft mehrerer Kr�fte, spanische Texte
// Letzte �nderung 08.09.2015

// Texte in HTML-Schreibweise:

var text01 = "N&uacute;mero de Fuerzas:";
var text02 = "Obtener Resultante";
var text03 = "Borrar Composici&oacute;n";

var author = "&copy;&nbsp; W. Fendt 1998";
var translator = "&copy; &nbsp;J. Mu&ntilde;oz 1999";
