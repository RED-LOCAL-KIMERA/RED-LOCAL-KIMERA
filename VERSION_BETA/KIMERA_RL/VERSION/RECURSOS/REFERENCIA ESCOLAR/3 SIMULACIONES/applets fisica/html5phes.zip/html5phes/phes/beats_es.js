// Schwebungen, spanische Texte (Jos� Miguel Zamarro)
// Letzte �nderung 07.01.2016

// Texte in HTML-Schreibweise:

var text01 = "Reiniciar";
var text02 = ["Iniciar", "Pausa", "Reanudar"];
var text03 = "Movimiento lento";
var text04 = "Frecuencias:";
var text05 = "1&ordf; onda:";
var text06 = "2&ordf; onda:";

var author = "&copy;&nbsp; W. Fendt 2001"; 
var translator = "&copy;&nbsp; J. M. Zamarro 2001";

// Symbole und Einheiten:

var hertz = "Hz";
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)

// Texte in Unicode-Schreibweise:          

// Symbole und Einheiten:

var symbolTime = "t";
var symbolElongation1 = "y_1";
var symbolElongation2 = "y_2";
var symbolElongation = "y";



