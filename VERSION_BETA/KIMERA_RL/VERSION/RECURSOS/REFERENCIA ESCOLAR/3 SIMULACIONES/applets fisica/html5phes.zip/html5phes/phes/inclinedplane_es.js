// Kr�fte an der schiefen Ebene, spanische Texte (Juan Munoz)
// Letzte �nderung 04.10.2015

// Texte in HTML-Schreibweise:

var text01 = "Inicio";
var text02 = ["Comenzar", "Pausa", "Reanudar"];
var text03 = "Ralentizado";
var text04 = "Dinam&oacute;metro";
var text05 = "Vectores de Fuerza";
var text06 = "&Aacute;ngulo de Inclinaci&oacute;n:";
var text07 = "Peso:";
var text08 = "Componente Paralela:";
var text09 = "Componente Normal:";
var text10 = "Coef. de Rozamiento:";
var text11 = "Fuerza de Rozamiento:";
var text12 = "Fuerza Necesaria:";

var author = "&copy;&nbsp; W. Fendt 1999,&nbsp; J. Mu&ntilde;oz 1999";

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var degree = "&deg;";                                      // Grad
var newton = "N";                                          // Newton
