// Gleichstrom-Elektromotor, spanische Texte (Juan Munoz)
// Letzte �nderung 20.09.2015

// Texte in HTML-Schreibweise;

var text01 = "Inicio";
var text02 = ["Comenzar", "Pausa", "Reanudar"];             
var text03 = "Cambiar Direcci&oacute;n";
var text04 = "Corriente";
var text05 = "Campo Magn&eacute;tico";
var text06 = "Fuerza de Lorentz";

var author = "&copy;&nbsp; W. Fendt 1997";               
var translator = "&copy;&nbsp; J. Mu&ntilde;oz 1999";    

// Symbole und Einheiten:
                                    
var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var rotationsPerMinute = "rot/min";                        // Umdrehungen pro Minute
