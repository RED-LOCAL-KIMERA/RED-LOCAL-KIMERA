// Gleichgewicht dreier Kr�fte, deutsche Texte
// Letzte �nderung 08.09.2015

// Texte in HTML-Schreibweise:

var text01 = "Fuerzas:";
var text02 = "Izquierda:";
var text03 = "Derecha:";
var text04 = "Abajo:";
var text05 = "Paralelogramo de fuerzas";
var text06 = "&Aacute;ngulos:";
var text07 = "Izquierda:";
var text08 = "Derecha:";

var author = "&copy;&nbsp; W. Fendt 2000";
var translator = "&copy;&nbsp; J. M. Zamarro 2001";

// Texte in Unicode-Schreibweise:

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Punkt)
var degree = "\u00b0";                                     // Symbol f�r Grad
var newton = "N";                                          // Abk�rzung f�r Newton
