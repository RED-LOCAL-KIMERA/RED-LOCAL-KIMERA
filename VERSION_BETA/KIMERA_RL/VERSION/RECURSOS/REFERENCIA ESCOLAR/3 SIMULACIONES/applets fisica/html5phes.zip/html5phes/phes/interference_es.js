// Interferenz zweier Kreis- oder Kugelwellen, spanische Texte (Jos� M. Zamarro)
// Letzte �nderung 16.09.2015

// Texte in HTML-Schreibweise:

var text01 = ["Pausa", "Reanudar"];                        // Schaltknopf (Pause/Weiter)
var text02 = "Movimiento lento";
var text03 = "Distancia de las dos";
var text04 = "fuentes:";
var text05 = "Longitud de onda:";

var author = "&copy;&nbsp; W. Fendt 1999";
var translator = "&copy;&nbsp; J. M. Zamarro 2001";

// Symbole und Einheiten:

var decimalSeparator = ".";                                // Dezimaltrennzeichen (Komma/Punkt)
var centimeter = "cm";                                     // Zentimeter

// Texte in Unicode-Schreibweise:

var text06 = "Diferencia de caminos:";
var text07 = "Interferencia constructiva (amplitud m\u00e1xima)";
var text08 = "Interferencia destructiva (amplitud m\u00ednima)";

// Symbole:

var symbolPhaseDifference = "\u0394s";                     // Symbol f�r Phasendifferenz (Delta s)
var symbolWavelength = "\u03bb";                           // Symbol f�r Wellenl�nge (Lambda)
