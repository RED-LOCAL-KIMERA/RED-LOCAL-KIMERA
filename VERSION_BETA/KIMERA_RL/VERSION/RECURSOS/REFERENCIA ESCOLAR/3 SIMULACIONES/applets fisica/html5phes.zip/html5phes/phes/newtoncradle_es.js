// Newtons Wiege, spanische Texte
// Letzte �nderung 11.09.2015

// Sprachabh�ngige Texte sind einer eigenen Datei (zum Beispiel newtoncradle_de.js) abgespeichert.

// Texte in HTML-Schreibweise:

var text01 = "Inicio";
var text02 = "Comenzar";
var text03 = "N&uacute;mero de part&iacute;culas:";

var author = "&copy;&nbsp; W. Fendt 1997";
var translator = "&copy;&nbsp; J. M. Zamarro 2001";
