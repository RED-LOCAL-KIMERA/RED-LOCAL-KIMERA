// Leiterschaukel-Versuch zur Lorentzkraft, spanische Texte (Juan Munoz)
// Letzte �nderung 17.09.2015

// Texte in HTML-Schreibweise:

var text01 = "Conectar / Desconectar";
var text02 = "Invertir Corriente";
var text03 = "Invertir Im&aacute;n";
var text04 = "Corriente";
var text05 = "Campo Magn&eacute;tico";
var text06 = "Fuerza de Lorentz";

var author = "&copy;&nbsp; W. Fendt 1998";
var translator = "&copy;&nbsp; J. Mu&ntilde;oz 1999";
