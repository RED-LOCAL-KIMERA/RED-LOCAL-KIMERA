// Magnetfeld eines geraden stromdurchflossenen Leiters, spanische Texte (Jos� Miguel Zamarro)
// Letzte �nderung 17.09.2015

// Texte in HTML-Schreibweise:

var text01 = "Invertir la corriente";

var author = "&copy;&nbsp; W. Fendt 2000";
var translator = "&copy;&nbsp; J. M. Zamarro 2001";
